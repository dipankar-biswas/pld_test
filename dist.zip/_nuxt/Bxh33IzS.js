import"./DttU9-nS.js";const t=""+new URL("avatar.DOoE-NIE.png",import.meta.url).href;export{t as _};
