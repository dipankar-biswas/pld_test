import{af as e,V as o,B as a}from"./DttU9-nS.js";import{b as r}from"./o4md7kPq.js";const i=e((s,u)=>{const t=r();if(o(),!t.getStatus)return a("/auth/login")});export{i as default};
