import"./DttU9-nS.js";const e=""+new URL("slider-1.ApOL9uE5.webp",import.meta.url).href;export{e as _};
