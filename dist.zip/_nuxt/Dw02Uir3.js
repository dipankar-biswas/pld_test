import{af as t,B as e}from"./DttU9-nS.js";import{b as o}from"./o4md7kPq.js";const f=t((a,r)=>{if(o().getStatus)return e("/user/dashboard")});export{f as default};
