import"./DttU9-nS.js";const r=""+new URL("dummy-image.CPPC7QAO.jpg",import.meta.url).href;export{r as _};
